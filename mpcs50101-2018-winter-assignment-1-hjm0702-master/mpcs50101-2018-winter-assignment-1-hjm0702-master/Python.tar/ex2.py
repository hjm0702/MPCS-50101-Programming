# A Comment, this is so you can read your program later.
# Anthing after # are ignored by Python.

print "I could have code like this." # and the comment after is ignored

# You can use comment "Disable" or comment out a piece of code :
# Print "This won't run."

print "This will run."
