tabby_cat = "\tI'm tabbed in."
persian_cat = "I'm split\non a line."
backslach_cat = "I'm \\ a \\ cat."

fat_cat = """f
I'll do a list:
\t* Cat food
\t* Fishies
\t* Catnip\n\t* Grass
"""

print tabby_cat
print persian_cat
print backslach_cat
print fat_cat

#while True:
#    for i in ["/", "-", "I", "\\", "I"]:
#        print "%s\r" % i,
